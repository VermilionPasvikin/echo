#include <arpa/inet.h>
#include <stdio.h>

int main(int argc,char *argv[])
{
    if (argc != 2)
    {
        fprintf(stderr, "用法: %s <十六进制 IP 地址>\n", argv[0]);
        return 1;
    }
 
    u_int32_t hexip;
    if((sscanf(argv[1],"%0x%x",&hexip) != 1))
    {
        fprintf(stderr,"错误：无效的十六进制格式。\n");
        return 1;
    }
    hexip = htonl(hexip);

    char ddstr[INET_ADDRSTRLEN];
    const char *ddptr = inet_ntop(AF_INET, &hexip, ddstr, INET_ADDRSTRLEN);
    printf("%s\n",ddstr);

    return 0;
}