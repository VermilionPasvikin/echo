 #include <arpa/inet.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <sys/types.h>
 #include <sys/socket.h>
 #include <netdb.h>      // 包含getaddrinfo等函数定义
 #include <unistd.h>     // 包含close函数
 #include <signal.h>
 #include <errno.h>
 int main(int argc,char *argv[]) {
     int sockfd = -1;         // 套接字文件描述符
     struct addrinfo hints;      // 地址信息模板
     struct addrinfo *servinfo;  // 存储获取的地址结果
     struct addrinfo *p;         // 用于遍历结果的指针
     struct sockaddr_in *sock_addr; // 用于指向套接字地址的指针
     char ip_addr_dd[INET_ADDRSTRLEN]; //ip地址的点分十进制形式字符串缓冲区，用完记得清零
     const char *ip_addr_dd_ptr;//指向ip地址的点分十进制形式字符串缓冲区的指针
     unsigned short sock_port;// 套接字地址中的端口部分，网络字节顺序存储（大端法）
     unsigned int ip_addr_hex;// 十六进制ip地址，网络字节顺序存储
     const char *hostname;

     if (argc != 3)
     {
         fprintf(stderr, "用法: %s <域名或点分十进制ip地址> <端口号>\n", argv[0]);
         return 1;
     }

      /* 要连接的目标信息 */
     int is_dd = 0;
     is_dd = inet_pton(AF_INET, argv[1], &ip_addr_hex);// 如果不是合法的点分十进制，参数1作为域名识别
     hostname = argv[1];

     const char *port = argv[2];//参数2作为端口识别
 
     /* 步骤1：初始化hints结构体，指定连接参数 */
     memset(&hints, 0, sizeof hints); // 清空结构体
     hints.ai_family = AF_INET;     // 支持IPv4
     hints.ai_socktype = SOCK_STREAM; // 使用流式套接字（TCP）
     hints.ai_protocol = IPPROTO_TCP; // 明确指定TCP协议
 
     int status;
     /* 步骤2：使用getaddrinfo解析域名和端口 */
     if ((status = getaddrinfo(hostname, port, &hints, &servinfo)) != 0) {
         fprintf(stderr, "getaddrinfo错误: %s\n", gai_strerror(status));
         return 1;
     }
 
     /* 步骤3：遍历所有返回的地址，尝试建立连接 */
     for(p = servinfo; p != NULL; p = p->ai_next) {
        // 当前正在连接的套接字
         sock_addr =  (struct sockaddr_in *)(p->ai_addr);
         sock_port = sock_addr->sin_port;
         ip_addr_dd_ptr = inet_ntop(AF_INET, &(sock_addr->sin_addr), ip_addr_dd, INET_ADDRSTRLEN);
         if (ip_addr_dd_ptr == NULL) {
             perror("inet_ntop 失败");
             freeaddrinfo(servinfo);
             close(sockfd);
             return 3;
         }
        
        // 3.1 创建套接字
         if ((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
             perror("socket创建失败");
             continue; // 尝试下一个地址
         }
 
         // 3.2 尝试连接
         if (is_dd)
         {
            printf("本次尝试：\n  ip-%s\n  端口-%d\n\n", ip_addr_dd, ntohs(sock_port));
         }
         else
         {
            printf("本次尝试：\n  域名-%s\n  ip-%s\n  端口-%d\n\n", hostname, ip_addr_dd, ntohs(sock_port));
         }

         if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
             close(sockfd); // 关闭当前失败的套接字
             perror("连接失败");
             continue;
         }
 
         memset(ip_addr_dd, 0 ,INET_ADDRSTRLEN * sizeof(char)); // 清除缓冲区

         // 连接成功，跳出循环
         break;
     }
 
     /* 检查是否所有地址都尝试失败 */
     if (p == NULL) {
         fprintf(stderr, "无法连接到 %s\n", hostname);
         freeaddrinfo(servinfo); // 释放地址信息内存
         return 2;
     }
 
     /* 步骤4：连接成功后的处理 */
     sock_addr = (struct sockaddr_in *)(p->ai_addr); // 从sockaddr反向转换为sockaddr_in
     sock_port = sock_addr->sin_port;

     // 将 IP 地址转换为点分十进制字符串
     ip_addr_dd_ptr = inet_ntop(AF_INET, &(sock_addr->sin_addr), ip_addr_dd, INET_ADDRSTRLEN);
     if (ip_addr_dd_ptr == NULL) {
         perror("inet_ntop 失败");
         freeaddrinfo(servinfo);
         close(sockfd);
         return 3;
     }

     if (is_dd)
     {
        printf("成功连接到 ip：%s， 端口：%d。\n", ip_addr_dd, ntohs(sock_port));
     }
     else
     {
        printf("成功连接到 域名：%s， ip：%s， 端口：%d。\n", hostname, ip_addr_dd, ntohs(sock_port));
     }
 
     /* 步骤5：清理资源 */
     close(sockfd);          // 关闭套接字
     freeaddrinfo(servinfo); // 释放地址信息
 
     return 0;
 }